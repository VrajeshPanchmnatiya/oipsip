from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import random
import string
import json
import os
import datetime

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this in production

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# JSON file path
USERS_FILE = os.path.join(os.path.dirname(__file__), 'users.json')

# Load users from JSON file
def load_users():
    if os.path.exists(USERS_FILE):
        with open(USERS_FILE, 'r') as f:
            data = json.load(f)
            return data.get('users', {})
    return {'test': {'password': 'test123', 'theme_preference': 'default', 'last_login': None, 'password_history': []}}

# Save users to JSON file
def save_users(users_data):
    with open(USERS_FILE, 'w') as f:
        json.dump({'users': users_data}, f, indent=2)

# Initialize users
users = load_users()
user_history = {}

class User(UserMixin):
    def __init__(self, username):
        self.id = username

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

# Password suggestion/hint function
def password_suggestions():
    return [
        "Use a mix of uppercase, lowercase, numbers, and symbols.",
        "Avoid using common words or easily guessable information.",
        "Longer passwords are generally stronger (12+ characters recommended).",
        "Do not reuse passwords across important accounts.",
        "Consider using a passphrase made of random words."
    ]

# Password generator function
def generate_password(length=12, use_upper=True, use_lower=True, use_digits=True, use_symbols=True):
    chars = ''
    if use_upper:
        chars += string.ascii_uppercase
    if use_lower:
        chars += string.ascii_lowercase
    if use_digits:
        chars += string.digits
    if use_symbols:
        chars += string.punctuation
    if not chars:
        return ''
    return ''.join(random.choice(chars) for _ in range(length))

# Get random theme
def get_random_theme():
    themes = ['default', 'dark', 'neon', 'pastel', 'sunset']
    return random.choice(themes)

@app.route('/')
@login_required
def index():
    # Update user's theme randomly if they don't have one
    if 'theme_preference' not in users[current_user.id]:
        users[current_user.id]['theme_preference'] = get_random_theme()
        save_users(users)
    
    return render_template('index.html', 
                          suggestions=password_suggestions(), 
                          user=current_user.id, 
                          theme=users[current_user.id]['theme_preference'])

@app.route('/generate', methods=['POST'])
@login_required
def generate():
    data = request.json
    length = int(data.get('length', 12))
    use_upper = data.get('use_upper', True)
    use_lower = data.get('use_lower', True)
    use_digits = data.get('use_digits', True)
    use_symbols = data.get('use_symbols', True)
    password = generate_password(length, use_upper, use_lower, use_digits, use_symbols)
    
    # Save to history in JSON
    if 'password_history' not in users[current_user.id]:
        users[current_user.id]['password_history'] = []
    
    users[current_user.id]['password_history'].append(password)
    save_users(users)
    
    # Also keep the in-memory history for compatibility
    user_history.setdefault(current_user.id, []).append(password)
    
    return jsonify({'password': password})

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username]['password'] == password:
            user = User(username)
            login_user(user)
            
            # Update last login time
            users[username]['last_login'] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Assign a random theme on login
            users[username]['theme_preference'] = get_random_theme()
            save_users(users)
            
            flash('Welcome back! Your theme today is ' + users[username]['theme_preference'], 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    username = current_user.id
    logout_user()
    flash('Thank you for using our Password Generator! Stay secure!', 'info')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users:
            flash('Username already exists', 'danger')
        else:
            users[username] = {
                'password': password,
                'theme_preference': get_random_theme(),
                'last_login': datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'password_history': []
            }
            save_users(users)
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/history')
@login_required
def history():
    history_data = users[current_user.id].get('password_history', [])
    return render_template('history.html', history=history_data, user=current_user.id, theme=users[current_user.id]['theme_preference'])

if __name__ == '__main__':
    app.run(debug=True)
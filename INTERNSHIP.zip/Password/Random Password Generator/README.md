# Random Password Generator Web App

This is a user-friendly random password generator web application built with Python (Flask) and Bootstrap.

## Features
- Generate strong random passwords
- Customize password length and character types
- Copy password to clipboard
- Get suggestions and tips for creating strong passwords
- Responsive, modern UI using Bootstrap

## How to Run

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
2. **Run the app:**
   ```bash
   python app.py
   ```
3. **Open your browser:**
   Go to [http://127.0.0.1:5000](http://127.0.0.1:5000)

## Folder Structure
- `app.py` - Flask backend
- `templates/index.html` - Frontend (Bootstrap)
- `requirements.txt` - Python dependencies

---
Feel free to customize and enhance the app! 
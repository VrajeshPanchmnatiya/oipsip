# Next-Gen BMI Health Tracker (Web Version)

A modern web-based BMI (Body Mass Index) Health Tracker application with an attractive Bootstrap UI/UX designed for ease of use. This application helps users monitor their BMI, track changes over time, and receive health insights based on their measurements.

## Features

- **Modern UI with Bootstrap**: Clean, responsive design that works on all devices
- **Step-by-Step Navigation**: Intuitive flow that guides users through the process
- **User Authentication**: Create an account and securely log in to track your personal BMI data
- **BMI Calculator**: Calculate your BMI with support for different units (metric and imperial)
- **History Tracking**: View and manage your BMI measurement history with sorting and filtering
- **Visual Insights**: See your BMI trends over time with interactive charts
- **Health Recommendations**: Get personalized advice based on your BMI category

## Requirements

- Python 3.6 or higher
- Required packages:
  - Flask
  - matplotlib

## Installation

1. Make sure you have Python installed on your computer
2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```
3. Run the web application:
   ```
   python bmi_tracker_web.py
   ```
4. Open your browser and navigate to:
   ```
   http://127.0.0.1:5000/
   ```

## How to Use

1. **Register/Login**:
   - Create a new account or log in with existing credentials
   - Your BMI data will be saved to your account
   - The step indicator shows you're at step 1 of the process

2. **Calculate BMI**:
   - Enter your height and weight (supports cm/m/feet and kg/lbs)
   - Enter your age and select your gender
   - Click "Calculate BMI" to see your results
   - Results include your BMI value, category, and health advice
   - The step indicator shows you're at step 2 of the process

3. **View History**:
   - See all your past BMI measurements in a table format
   - Sort by newest first, oldest first, or BMI value
   - Search for specific entries
   - Delete any unwanted entries
   - The step indicator shows you're at step 3 of the process

4. **Check Insights**:
   - View a graph of your BMI changes over time
   - See reference lines for different BMI categories
   - Get statistics about your average BMI and overall change
   - The step indicator shows you're at step 3 of the process

## BMI Categories

- **Underweight**: BMI less than 18.5
- **Normal Weight**: BMI between 18.5 and 24.9
- **Overweight**: BMI between 25 and 29.9
- **Obese**: BMI of 30 or higher

## Data Storage

All user data is stored locally in a JSON file named `bmi_data.json`. Your password and BMI history are saved in this file.

## UI/UX Improvements

- **Bootstrap Framework**: Modern, responsive design that looks great on all devices
- **Step Indicators**: Visual guides showing your progress through the application
- **Color-Coded BMI Categories**: Easy visual identification of BMI status
- **Interactive Charts**: Dynamic visualization of your BMI trends
- **Improved Navigation**: Intuitive menu system for moving between features
- **Form Validation**: Immediate feedback on input errors
- **Responsive Tables**: Mobile-friendly data presentation
- **Attractive Cards**: Well-organized information presentation

## Future Improvements

- Password encryption for better security
- More detailed health insights and recommendations
- Export data functionality
- Goal setting and achievement tracking
- Diet and exercise recommendations

## Disclaimer

This application is for educational purposes only. Always consult with healthcare professionals for medical advice related to your BMI and health status.
// BMI Health Tracker Enhanced JavaScript

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('fade-in');
        }, index * 100);
    });
    
    // User dropdown toggle
    const userDropdown = document.querySelector('.user-dropdown');
    if (userDropdown) {
        userDropdown.addEventListener('click', function() {
            const dropdown = document.querySelector('.user-dropdown-menu');
            dropdown.classList.toggle('show');
        });
    }
    
    // BMI Calculator enhancements
    const bmiForm = document.getElementById('bmi-form');
    if (bmiForm) {
        // Real-time BMI calculation preview
        const heightInput = document.getElementById('height');
        const weightInput = document.getElementById('weight');
        const heightUnitSelect = document.getElementById('height_unit');
        const weightUnitSelect = document.getElementById('weight_unit');
        const previewElement = document.getElementById('bmi-preview');
        
        function updateBMIPreview() {
            if (heightInput.value && weightInput.value) {
                let height = parseFloat(heightInput.value);
                let weight = parseFloat(weightInput.value);
                
                // Convert height based on unit
                if (heightUnitSelect.value === 'cm') {
                    height = height / 100; // Convert cm to m
                } else if (heightUnitSelect.value === 'feet') {
                    height = height * 0.3048; // Convert feet to m
                }
                
                // Convert weight based on unit
                if (weightUnitSelect.value === 'lbs') {
                    weight = weight * 0.453592; // Convert lbs to kg
                }
                
                // Calculate BMI
                const bmi = weight / (height * height);
                
                if (previewElement) {
                    previewElement.textContent = `Estimated BMI: ${bmi.toFixed(2)}`;
                    previewElement.style.display = 'block';
                }
            }
        }
        
        if (heightInput && weightInput) {
            heightInput.addEventListener('input', updateBMIPreview);
            weightInput.addEventListener('input', updateBMIPreview);
            heightUnitSelect.addEventListener('change', updateBMIPreview);
            weightUnitSelect.addEventListener('change', updateBMIPreview);
        }
    }
    
    // Password strength meter
    const passwordInput = document.getElementById('password');
    const strengthMeter = document.getElementById('password-strength');
    
    if (passwordInput && strengthMeter) {
        passwordInput.addEventListener('input', function() {
            const password = passwordInput.value;
            let strength = 0;
            
            if (password.length >= 8) strength += 1;
            if (password.match(/[a-z]+/)) strength += 1;
            if (password.match(/[A-Z]+/)) strength += 1;
            if (password.match(/[0-9]+/)) strength += 1;
            if (password.match(/[^a-zA-Z0-9]+/)) strength += 1;
            
            switch (strength) {
                case 0:
                case 1:
                    strengthMeter.style.width = '20%';
                    strengthMeter.className = 'progress-bar bg-danger';
                    break;
                case 2:
                    strengthMeter.style.width = '40%';
                    strengthMeter.className = 'progress-bar bg-warning';
                    break;
                case 3:
                    strengthMeter.style.width = '60%';
                    strengthMeter.className = 'progress-bar bg-info';
                    break;
                case 4:
                    strengthMeter.style.width = '80%';
                    strengthMeter.className = 'progress-bar bg-primary';
                    break;
                case 5:
                    strengthMeter.style.width = '100%';
                    strengthMeter.className = 'progress-bar bg-success';
                    break;
            }
        });
    }
});
# Add these imports at the top of the file
import os
import json
import uuid
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory

app = Flask(__name__)
app.secret_key = 'bmi_tracker_secret_key'

# Set the data file path
parent_dir = os.path.dirname(os.path.abspath(__file__))
data_file = os.path.join(parent_dir, "bmi_data.json")

# Password reset tokens storage
reset_tokens = {}

# Load existing data
def load_data():
    if os.path.exists(data_file):
        with open(data_file, 'r') as f:
            return json.load(f)
    return {}

# Save data
def save_data(data):
    with open(data_file, 'w') as f:
        json.dump(data, f, indent=4)

# Calculate BMI
def calculate_bmi(height, weight, height_unit='m', weight_unit='kg'):
    # Convert height to meters
    if height_unit == 'cm':
        height = height / 100
    elif height_unit == 'feet':
        height = height * 0.3048
    
    # Convert weight to kg
    if weight_unit == 'lbs':
        weight = weight * 0.453592
    
    # Calculate BMI
    bmi = weight / (height * height)
    return round(bmi, 2)

# Get BMI category
def get_bmi_category(bmi):
    if bmi < 18.5:
        return "Underweight"
    elif 18.5 <= bmi < 25:
        return "Normal weight"
    elif 25 <= bmi < 30:
        return "Overweight"
    else:
        return "Obese"

# Get health advice based on BMI category
def get_health_advice(category):
    advice = {
        "Underweight": "You are underweight. Consider consulting with a healthcare professional about a balanced diet to gain weight healthily.",
        "Normal weight": "You have a healthy weight. Maintain your balanced diet and regular physical activity.",
        "Overweight": "You are overweight. Consider increasing physical activity and adopting a balanced diet to reach a healthier weight.",
        "Obese": "You are in the obese category. It's recommended to consult with a healthcare professional for a personalized weight management plan."
    }
    return advice.get(category, "")

# Routes
@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    user_data = load_data()
    username = session['username']
    history = user_data[username].get("history", [])
    
    # Calculate statistics if history exists
    stats = {}
    if history:
        bmi_values = [entry['bmi'] for entry in history]
        stats['avg_bmi'] = round(sum(bmi_values) / len(bmi_values), 2)
        stats['current_bmi'] = bmi_values[-1]
        stats['current_category'] = get_bmi_category(stats['current_bmi'])
        
        # Get latest 5 entries for carousel
        latest_entries = sorted(history, key=lambda x: x['date'], reverse=True)[:5]
    else:
        latest_entries = []
    
    return render_template('dashboard.html', 
                           username=username,
                           history=history,
                           latest_entries=latest_entries,
                           stats=stats if history else None)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user_data = load_data()
        
        if username in user_data and user_data[username]["password"] == password:
            session['username'] = username
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        user_data = load_data()
        
        if username in user_data:
            flash('Username already exists', 'danger')
        elif password != confirm_password:
            flash('Passwords do not match', 'danger')
        else:
            user_data[username] = {
                "password": password,
                "history": [],
                "profile": {
                    "display_name": username,
                    "email": "",
                    "avatar": "default.png",
                    "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
            save_data(user_data)
            flash('Registration successful! Please login.', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        username = request.form['username']
        user_data = load_data()
        
        if username in user_data:
            # Generate a unique token
            token = str(uuid.uuid4())
            
            # Store token with expiration (24 hours)
            reset_tokens[token] = {
                'username': username,
                'expires': datetime.now() + timedelta(hours=24)
            }
            
            # In a real application, you would send an email with the reset link
            # For demo purposes, we'll just show the token
            reset_link = url_for('reset_password', token=token, _external=True)
            flash(f'Password reset link (for demo only): {reset_link}', 'info')
            return redirect(url_for('login'))
        else:
            flash('Username not found', 'danger')
    
    return render_template('forgot_password.html')

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    # Check if token exists and is valid
    if token not in reset_tokens or datetime.now() > reset_tokens[token]['expires']:
        flash('Invalid or expired password reset link', 'danger')
        return redirect(url_for('forgot_password'))
    
    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        
        if new_password != confirm_password:
            flash('Passwords do not match', 'danger')
        else:
            # Update the user's password
            username = reset_tokens[token]['username']
            user_data = load_data()
            user_data[username]['password'] = new_password
            save_data(user_data)
            
            # Remove the used token
            del reset_tokens[token]
            
            flash('Password has been reset successfully', 'success')
            return redirect(url_for('login'))
    
    return render_template('reset_password.html')

@app.route('/calculator', methods=['GET', 'POST'])
def calculator():
    if 'username' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    bmi_result = None
    bmi_category = None
    health_advice = None
    
    if request.method == 'POST':
        height = float(request.form['height'])
        weight = float(request.form['weight'])
        height_unit = request.form['height_unit']
        weight_unit = request.form['weight_unit']
        age = int(request.form['age'])
        gender = request.form['gender']
        
        bmi = calculate_bmi(height, weight, height_unit, weight_unit)
        bmi_category = get_bmi_category(bmi)
        health_advice = get_health_advice(bmi_category)
        
        # Save to history
        user_data = load_data()
        username = session['username']
        
        history_entry = {
            "date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "height": f"{height} {height_unit}",
            "weight": f"{weight} {weight_unit}",
            "age": age,
            "gender": gender,
            "bmi": bmi,
            "category": bmi_category
        }
        
        user_data[username]["history"].append(history_entry)
        save_data(user_data)
        
        bmi_result = bmi
    
    return render_template('calculator.html', 
                           bmi_result=bmi_result, 
                           bmi_category=bmi_category, 
                           health_advice=health_advice)

@app.route('/history')
def history():
    if 'username' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    user_data = load_data()
    username = session['username']
    history = user_data[username].get("history", [])
    
    # Sort by date (newest first by default)
    sort_by = request.args.get('sort', 'date_desc')
    
    if sort_by == 'date_asc':
        history = sorted(history, key=lambda x: x['date'])
    elif sort_by == 'date_desc':
        history = sorted(history, key=lambda x: x['date'], reverse=True)
    elif sort_by == 'bmi':
        history = sorted(history, key=lambda x: x['bmi'])
    
    return render_template('history.html', history=history, sort_by=sort_by)

@app.route('/delete_entry/<int:index>')
def delete_entry(index):
    if 'username' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    user_data = load_data()
    username = session['username']
    
    try:
        user_data[username]["history"].pop(index)
        save_data(user_data)
        flash('Entry deleted successfully', 'success')
    except IndexError:
        flash('Entry not found', 'danger')
    
    return redirect(url_for('history'))

@app.route('/insights')
def insights():
    if 'username' not in session:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    
    user_data = load_data()
    username = session['username']
    history = user_data[username].get("history", [])
    
    if not history:
        flash('No BMI data available for insights', 'info')
        return redirect(url_for('calculator'))
    
    # Calculate statistics
    bmi_values = [entry['bmi'] for entry in history]
    avg_bmi = round(sum(bmi_values) / len(bmi_values), 2)
    
    # Calculate BMI change (current vs first)
    bmi_change = round(bmi_values[-1] - bmi_values[0], 2)
    
    # Current status
    current_status = get_bmi_category(bmi_values[-1])
    
    # Prepare data for chart
    dates = [entry['date'] for entry in history]
    
    return render_template('insights.html', 
                           history=history,
                           avg_bmi=avg_bmi,
                           bmi_change=bmi_change,
                           current_status=current_status,
                           dates=dates,
                           bmi_values=bmi_values)

# Serve static files
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(app.static_folder, filename)

if __name__ == '__main__':
    # Create directories if they don't exist
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
    if not os.path.exists(templates_dir):
        os.makedirs(templates_dir)
    
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
    if not os.path.exists(static_dir):
        os.makedirs(static_dir)
    
    static_images_dir = os.path.join(static_dir, "images")
    if not os.path.exists(static_images_dir):
        os.makedirs(static_images_dir)
    
    app.run(debug=True)
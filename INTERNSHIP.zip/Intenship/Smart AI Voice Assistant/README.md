# Smart AI Voice Assistant

A modern, user-friendly voice assistant built with Python. This application provides a graphical user interface and voice interaction capabilities to help you with various tasks.

## Features

- **Voice Recognition**: Understand and process voice commands
- **Text-to-Speech**: Respond to your queries with a natural-sounding voice
- **Modern UI**: Clean and intuitive graphical interface
- **Wikipedia Search**: Look up information directly from Wikipedia
- **Web Browsing**: Open popular websites like Google and YouTube
- **Time and Date**: Get current time and date information
- **Jokes**: Enjoy some humor with random jokes
- **Customizable Settings**: Change assistant name, voice type, and speech rate

## Installation

1. Make sure you have Python 3.6 or higher installed
2. Clone this repository or download the files
3. Install the required packages:

```bash
pip install -r requirements.txt
```

4. Run the application:

```bash
python voice_assistant.py
```

## Usage

### Voice Commands

You can interact with the assistant using the following voice commands:

- **Greeting**: "Hello" or "Hi"
- **Time**: "What's the time?" or "Tell me the time"
- **Date**: "What's the date today?" or "Tell me the date"
- **Wikipedia**: "Search Wikipedia for [topic]" or "Wikipedia [topic]"
- **Open Websites**: "Open Google" or "Open YouTube"
- **Weather**: "What's the weather like?" or "Tell me the weather"
- **Jokes**: "Tell me a joke" or "Do you know any jokes?"
- **Exit**: "Exit" or "Quit" or "Bye"

### Text Input

You can also type commands in the text input field at the bottom of the application.

### Settings

Click the "Settings" button to customize:

- Assistant name
- User name
- Voice type (Male/Female)
- Speech rate

## Extending the Assistant

You can easily extend the functionality of this voice assistant by adding new commands in the `process_command` method of the `SmartVoiceAssistant` class.

## Requirements

See `requirements.txt` for a list of required Python packages.

## License

This project is open source and available for personal and educational use.

## Acknowledgements

- Speech recognition powered by Google Speech Recognition API
- Text-to-speech powered by pyttsx3
- Wikipedia information retrieval using the Wikipedia API
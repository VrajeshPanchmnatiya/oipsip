import tkinter as tk
import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import random
import sys
import re
import os
import json
import threading
from io import BytesIO
from tkinter import messagebox, filedialog
from tkinter import ttk, scrolledtext
from PIL import Image, ImageTk
import pyaudio
import wave
import pygame
import requests
import time
from urllib.request import urlopen
from urllib.parse import quote_plus

class SmartVoiceAssistant:
    def __init__(self, root):
        # Initialize the main window
        self.root = root
        self.root.title("Smart AI Voice Assistant")
        self.root.geometry("900x650")
        self.root.resizable(True, True)
        self.root.configure(bg="#1E1E2E")  # Dark theme background
        
        # Set minimum window size
        self.root.minsize(800, 600)
        
        # Set app icon
        try:
            self.root.iconbitmap("assistant_icon.ico")
        except:
            pass
        
        # Initialize text-to-speech engine
        self.engine = pyttsx3.init()
        self.voices = self.engine.getProperty('voices')
        self.engine.setProperty('voice', self.voices[1].id)  # Default to female voice
        self.engine.setProperty('rate', 180)  # Speed of speech
        
        # Initialize speech recognizer
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 4000
        self.recognizer.dynamic_energy_threshold = True
        
        # Assistant state
        self.listening = False
        self.assistant_name = "Jarvis"
        self.user_name = "User"
        self.theme_color = "#89DCEB"  # Accent color
        self.conversation_history = []
        self.is_first_click = True  # For text input placeholder
        
        # Load SVG images
        self.avatar_path = "assistant_avatar.svg"
        self.help_icon_path = "help_icon.svg"
        self.quick_icons_path = "quick_action_icons.svg"
        
        # Create a dictionary to store conversation history
        self.chat_history = []
        
        # Set up fonts
        self.header_font = ("Segoe UI", 18, "bold")
        self.title_font = ("Segoe UI", 14, "bold")
        self.normal_font = ("Segoe UI", 11)
        self.small_font = ("Segoe UI", 10)
        self.button_font = ("Segoe UI", 11, "bold")
        
        # Knowledge base for quick responses
        self.knowledge_base = {
            # India related information
            "prime minister of india": "Narendra Modi is the current Prime Minister of India.",
            "president of india": "Droupadi Murmu is the current President of India.",
            "capital of india": "New Delhi is the capital of India.",
            "population of india": "India has a population of approximately 1.4 billion people.",
            "largest democracy": "India is the world's largest democracy.",
            "currency of india": "The Indian Rupee (₹) is the currency of India.",
            "national animal of india": "The Bengal Tiger is the national animal of India.",
            "national bird of india": "The Indian Peacock is the national bird of India.",
            "national flower of india": "The Lotus is the national flower of India.",
            "national anthem of india": "Jana Gana Mana is the national anthem of India.",
            "national song of india": "Vande Mataram is the national song of India.",
            "independence day of india": "India celebrates its Independence Day on August 15.",
            "republic day of india": "India celebrates Republic Day on January 26.",
            "chief justice of india": "Justice D.Y. Chandrachud is the current Chief Justice of India.",
            "vice president of india": "Jagdeep Dhankhar is the current Vice President of India.",
            "states in india": "India has 28 states and 8 Union Territories.",
            "largest state in india": "Rajasthan is the largest state in India by area.",
            "smallest state in india": "Goa is the smallest state in India by area.",
            "most populated state in india": "Uttar Pradesh is the most populated state in India.",
            "national game of india": "Hockey is considered the national game of India.",
            "national tree of india": "The Banyan tree is the national tree of India.",
            "national fruit of india": "Mango is the national fruit of India.",
            "national river of india": "The Ganges (Ganga) is the national river of India.",
            "national aquatic animal of india": "The Ganges River Dolphin is the national aquatic animal of India.",
            "national heritage animal of india": "The Indian Elephant is the national heritage animal of India.",
            "national calendar of india": "The Saka Calendar is the national calendar of India.",
            "national language of india": "India does not have a national language. Hindi and English are the official languages of the Union Government.",
            "languages in india": "India has 22 officially recognized languages in its Constitution.",
            
            # World information
            "largest country": "Russia is the largest country in the world by land area.",
            "smallest country": "Vatican City is the smallest country in the world.",
            "tallest mountain": "Mount Everest is the tallest mountain in the world.",
            "deepest ocean": "The Mariana Trench in the Pacific Ocean is the deepest known part of the world's oceans.",
            "fastest animal": "The Peregrine Falcon is the fastest animal, capable of reaching speeds over 240 mph during its hunting dive.",
            "largest animal": "The Blue Whale is the largest animal on Earth.",
            "largest ocean": "The Pacific Ocean is the largest and deepest ocean on Earth.",
            "largest river": "The Nile is the longest river in the world, while the Amazon is the largest by water volume.",
            "largest desert": "The Sahara Desert is the largest hot desert in the world.",
            "most populated country": "India is now the most populated country in the world, surpassing China.",
            "seven wonders of the world": "The Seven Wonders of the Modern World are: Great Wall of China, Christ the Redeemer, Machu Picchu, Chichen Itza, Colosseum, Taj Mahal, and Petra.",
            
            # Technology and business
            "ceo of microsoft": "Satya Nadella is the CEO of Microsoft.",
            "ceo of apple": "Tim Cook is the CEO of Apple.",
            "ceo of google": "Sundar Pichai is the CEO of Google and its parent company Alphabet.",
            "ceo of amazon": "Andy Jassy is the CEO of Amazon.",
            "ceo of tesla": "Elon Musk is the CEO of Tesla.",
            "ceo of meta": "Mark Zuckerberg is the CEO of Meta (formerly Facebook).",
            "founder of microsoft": "Bill Gates and Paul Allen founded Microsoft.",
            "founder of apple": "Steve Jobs, Steve Wozniak, and Ronald Wayne founded Apple.",
            "founder of google": "Larry Page and Sergey Brin founded Google.",
            "founder of amazon": "Jeff Bezos founded Amazon.",
            "founder of tesla": "Martin Eberhard and Marc Tarpenning founded Tesla, with Elon Musk joining as an early investor and later becoming CEO.",
            "founder of facebook": "Mark Zuckerberg founded Facebook, now known as Meta.",
            "richest person in the world": "Elon Musk is currently the richest person in the world.",
            
            # Science and space
            "hottest planet": "Venus is the hottest planet in our solar system.",
            "closest star": "Proxima Centauri is the closest star to our solar system.",
            "planets in solar system": "There are eight planets in our solar system: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.",
            "largest planet": "Jupiter is the largest planet in our solar system.",
            "smallest planet": "Mercury is the smallest planet in our solar system.",
            "first man on moon": "Neil Armstrong was the first human to walk on the Moon on July 20, 1969.",
            "first woman in space": "Valentina Tereshkova was the first woman in space, aboard Vostok 6 in 1963.",
            "first indian in space": "Rakesh Sharma was the first Indian to travel to space in 1984.",
            "speed of light": "The speed of light in a vacuum is approximately 299,792,458 meters per second.",
            "periodic table elements": "There are currently 118 confirmed elements in the periodic table.",
            
            # Sports
            "most popular sport": "Soccer (football) is the most popular sport in the world.",
            "cricket world cup winner": "Australia has won the Cricket World Cup the most times (5), with India winning it twice (1983 and 2011).",
            "football world cup winner": "Argentina is the current FIFA World Cup champion (2022).",
            "olympic games": "The Olympic Games are held every four years, with the Summer and Winter Olympics alternating every two years.",
            "ipl teams": "The Indian Premier League (IPL) currently has 10 teams: Chennai Super Kings, Delhi Capitals, Gujarat Titans, Kolkata Knight Riders, Lucknow Super Giants, Mumbai Indians, Punjab Kings, Rajasthan Royals, Royal Challengers Bangalore, and Sunrisers Hyderabad.",
            
            # Health and medicine
            "human body temperature": "The normal human body temperature is around 98.6°F (37°C).",
            "human heart": "The human heart beats about 100,000 times per day, pumping about 2,000 gallons of blood.",
            "human bones": "An adult human has 206 bones in their body.",
            "blood types": "The four main blood types are A, B, AB, and O, each being either Rh positive or negative.",
            "covid vaccine": "Several COVID-19 vaccines have been developed, including those by Pfizer-BioNTech, Moderna, Oxford-AstraZeneca, Johnson & Johnson, and others.",
            
            # General knowledge
            "water boiling point": "Water boils at 100°C (212°F) at standard atmospheric pressure.",
            "water freezing point": "Water freezes at 0°C (32°F) at standard atmospheric pressure.",
            "highest waterfall": "Angel Falls in Venezuela is the world's highest uninterrupted waterfall.",
            "deepest lake": "Lake Baikal in Russia is the deepest lake in the world.",
            "largest lake": "The Caspian Sea is the largest lake in the world by surface area.",
            "largest bird": "The ostrich is the largest living bird in the world.",
            "fastest bird": "The peregrine falcon is the fastest bird and the fastest member of the animal kingdom.",
            "tallest building": "The Burj Khalifa in Dubai is currently the tallest building in the world."
        }
        
        # Famous people list
        self.famous_people = [
            "gandhiji", "mahatma gandhi", "narendra modi", "apj abdul kalam", "sachin tendulkar", "virat kohli", "amitabh bachchan", "indira gandhi", "jawaharlal nehru", "sardar vallabhbhai patel", "subhas chandra bose", "bhagat singh", "dr. b. r. ambedkar", "lal bahadur shastri", "atal bihari vajpayee", "rajiv gandhi", "mother teresa", "kalpana chawla", "ratan tata", "dhirubhai ambani"
        ]
        
        # Configure ttk style for modern UI elements
        self.configure_styles()
        
        # Create the UI
        self.create_ui()
        
        # Welcome message
        self.update_conversation(f"{self.assistant_name}: Hello! I'm {self.assistant_name}, your personal voice assistant. How can I help you today?")
        self.speak(f"Hello! I'm {self.assistant_name}, your personal voice assistant. How can I help you today?")
    
    def configure_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton", font=("Segoe UI", 11), background=self.theme_color)
        style.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), background=self.theme_color)
        style.configure("TFrame", background="#1E1E2E")
        style.configure("TLabel", background="#1E1E2E", foreground="#CDD6F4")
        style.configure("TScale", background="#1E1E2E")
    
    def create_ui(self):
        # Configure ttk style for modern look
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("TButton", font=("Segoe UI", 11), background=self.theme_color)
        style.configure("Accent.TButton", font=("Segoe UI", 11, "bold"), background=self.theme_color)
        style.configure("TFrame", background="#1E1E2E")
        style.configure("TLabel", background="#1E1E2E", foreground="#CDD6F4")
        style.configure("TScale", background="#1E1E2E")
        
        # Create main container with padding
        container = ttk.Frame(self.root, padding="20 20 20 20")
        container.pack(fill=tk.BOTH, expand=True)
        
        # Create header frame
        header_frame = ttk.Frame(container)
        header_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Assistant logo/avatar (placeholder for a circular avatar)
        avatar_frame = ttk.Frame(header_frame, width=60, height=60)
        avatar_frame.pack(side=tk.LEFT, padx=(0, 15))
        
        # Create a canvas for the circular avatar
        avatar_canvas = tk.Canvas(avatar_frame, width=60, height=60, bg="#1E1E2E", highlightthickness=0)
        avatar_canvas.pack()
        
        # Draw a circular background
        avatar_canvas.create_oval(5, 5, 55, 55, fill=self.theme_color, outline="")
        avatar_canvas.create_text(30, 30, text=self.assistant_name[0].upper(), fill="#1E1E2E", font=("Segoe UI", 24, "bold"))
        
        # Title and subtitle in header
        title_frame = ttk.Frame(header_frame)
        title_frame.pack(side=tk.LEFT, fill=tk.Y, pady=5)
        
        title_label = tk.Label(title_frame, text="Smart AI Voice Assistant", 
                              font=("Segoe UI", 22, "bold"), 
                              fg="#CDD6F4", bg="#1E1E2E")
        title_label.pack(anchor="w")
        
        subtitle_label = tk.Label(title_frame, text="Your intelligent personal assistant", 
                                font=("Segoe UI", 11), 
                                fg="#A6ADC8", bg="#1E1E2E")
        subtitle_label.pack(anchor="w")
        
        # Main content area with conversation and features
        content_frame = ttk.Frame(container)
        content_frame.pack(fill=tk.BOTH, expand=True)
        
        # Create a frame for the conversation area (left side)
        conversation_frame = ttk.Frame(content_frame)
        conversation_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Conversation display with custom styling
        self.conversation_display = scrolledtext.ScrolledText(
            conversation_frame, 
            font=("Segoe UI", 11),
            bg="#313244", 
            fg="#CDD6F4",
            insertbackground="#CDD6F4",
            selectbackground=self.theme_color,
            selectforeground="#1E1E2E",
            wrap=tk.WORD,
            padx=10,
            pady=10,
            borderwidth=0,
            height=15
        )
        self.conversation_display.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.conversation_display.config(state=tk.DISABLED)
        
        # Create a frame for quick actions and features (right side)
        features_frame = ttk.Frame(content_frame, width=200)
        features_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(15, 0))
        features_frame.pack_propagate(False)  # Prevent frame from shrinking
        
        # Features label
        features_label = tk.Label(features_frame, text="Quick Actions", 
                                font=("Segoe UI", 14, "bold"), 
                                fg="#CDD6F4", bg="#1E1E2E")
        features_label.pack(anchor="w", pady=(0, 10))
        
        # Quick action buttons
        quick_actions = [
            ("🔍 Wikipedia Search", lambda: self.show_feature_help("Wikipedia Search", "Say 'Search Wikipedia for [topic]'")),
            ("🌐 Open Website", lambda: self.show_feature_help("Open Website", "Say 'Open Google' or 'Open YouTube'")),
            ("❓ Ask a Question", lambda: self.show_feature_help("Knowledge Base", "Ask 'Who is the Prime Minister of India?'")),
            ("⏰ Time & Date", lambda: self.show_feature_help("Time & Date", "Ask 'What's the time?' or 'What's the date today?'")),
            ("😄 Tell a Joke", lambda: self.tell_joke())
        ]
        
        for text, command in quick_actions:
            action_btn = tk.Button(
                features_frame, 
                text=text, 
                font=("Segoe UI", 11),
                bg="#313244",
                fg="#CDD6F4",
                activebackground=self.theme_color,
                activeforeground="#1E1E2E",
                relief=tk.FLAT,
                padx=10,
                pady=8,
                anchor="w",
                command=command
            )
            action_btn.pack(fill=tk.X, pady=5)
        
        # Bottom control area
        controls_frame = ttk.Frame(container)
        controls_frame.pack(fill=tk.X, pady=(15, 0))
        
        # Status indicator with icon
        status_frame = ttk.Frame(controls_frame)
        status_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        
        status_icon = tk.Canvas(status_frame, width=12, height=12, bg="#1E1E2E", highlightthickness=0)
        status_icon.create_oval(0, 0, 12, 12, fill="#2ECC71", outline="")
        status_icon.pack(side=tk.LEFT, padx=(0, 5))
        
        status_label = tk.Label(status_frame, 
                              textvariable=self.status_var,
                              font=("Segoe UI", 11),
                              fg="#A6ADC8", 
                              bg="#1E1E2E")
        status_label.pack(side=tk.LEFT)
        
        # Button frame
        button_frame = ttk.Frame(controls_frame)
        button_frame.pack(side=tk.RIGHT)
        
        # Control buttons with icons (text representation of icons)
        self.listen_button = tk.Button(button_frame, 
                                    text="🎤 Listen", 
                                    font=("Segoe UI", 11),
                                    bg=self.theme_color,
                                    fg="#1E1E2E",
                                    activebackground="#74C7EC",
                                    activeforeground="#1E1E2E",
                                    relief=tk.FLAT,
                                    padx=15,
                                    pady=8,
                                    command=self.toggle_listening)
        self.listen_button.pack(side=tk.LEFT, padx=5)
        
        self.stop_button = tk.Button(button_frame, 
                                   text="⏹ Stop", 
                                   font=("Segoe UI", 11),
                                   bg="#F38BA8",
                                   fg="#1E1E2E",
                                   activebackground="#F38BA8",
                                   activeforeground="#1E1E2E",
                                   relief=tk.FLAT,
                                   padx=15,
                                   pady=8,
                                   state=tk.DISABLED,
                                   command=self.stop_listening)
        self.stop_button.pack(side=tk.LEFT, padx=5)
        
        self.settings_button = tk.Button(button_frame, 
                                      text="⚙️ Settings", 
                                      font=("Segoe UI", 11),
                                      bg="#313244",
                                      fg="#CDD6F4",
                                      activebackground="#45475A",
                                      activeforeground="#CDD6F4",
                                      relief=tk.FLAT,
                                      padx=15,
                                      pady=8,
                                      command=self.open_settings)
        self.settings_button.pack(side=tk.LEFT, padx=5)
        
        self.exit_button = tk.Button(button_frame, 
                                   text="❌ Exit", 
                                   font=("Segoe UI", 11),
                                   bg="#313244",
                                   fg="#CDD6F4",
                                   activebackground="#45475A",
                                   activeforeground="#CDD6F4",
                                   relief=tk.FLAT,
                                   padx=15,
                                   pady=8,
                                   command=self.exit_app)
        self.exit_button.pack(side=tk.LEFT, padx=5)
        
        # Text input area
        input_frame = ttk.Frame(container)
        input_frame.pack(fill=tk.X, pady=(15, 0))
        
        # Text input with placeholder
        self.text_input = tk.Entry(input_frame, 
                                font=("Segoe UI", 12),
                                bg="#313244",
                                fg="#CDD6F4",
                                insertbackground="#CDD6F4",
                                relief=tk.FLAT,
                                bd=10)  # Inner padding
        self.text_input.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 10))
        self.text_input.bind("<Return>", self.process_text_input)
        
        # Add placeholder text
        self.text_input.insert(0, "Type your message here...")
        self.text_input.bind("<FocusIn>", self.on_entry_click)
        self.text_input.bind("<FocusOut>", self.on_focus_out)
        
        # Send button
        self.send_button = tk.Button(input_frame, 
                                   text="📤 Send", 
                                   font=("Segoe UI", 11),
                                   bg=self.theme_color,
                                   fg="#1E1E2E",
                                   activebackground="#74C7EC",
                                   activeforeground="#1E1E2E",
                                   relief=tk.FLAT,
                                   padx=15,
                                   pady=8,
                                   command=self.process_text_input)
        self.send_button.pack(side=tk.RIGHT)
    
    def on_entry_click(self, event):
        """Function to handle click on the entry (remove placeholder)"""
        if self.text_input.get() == "Type your message here...":
            self.text_input.delete(0, tk.END)
            self.text_input.config(fg="#CDD6F4")
    
    def on_focus_out(self, event):
        """Function to handle focus out of the entry (restore placeholder if empty)"""
        if self.text_input.get() == "":
            self.text_input.insert(0, "Type your message here...")
            self.text_input.config(fg="#A6ADC8")
    
    def show_feature_help(self, feature_name, help_text):
        """Display help for a specific feature"""
        self.update_conversation(f"{self.assistant_name}: {feature_name} - {help_text}")
        self.speak(f"{feature_name}. {help_text}")
    
    def update_conversation(self, message):
        self.conversation_display.config(state=tk.NORMAL)
        self.conversation_display.insert(tk.END, message + "\n\n")
        self.conversation_display.see(tk.END)
        self.conversation_display.config(state=tk.DISABLED)
    
    def speak(self, text):
        # Function to convert text to speech
        self.engine.say(text)
        self.engine.runAndWait()
    
    def toggle_listening(self):
        if not self.listening:
            self.start_listening()
        else:
            self.stop_listening()
    
    def start_listening(self):
        self.listening = True
        self.status_var.set("Listening...")
        self.listen_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        
        # Start listening in a separate thread
        threading.Thread(target=self.listen_for_command, daemon=True).start()
    
    def stop_listening(self):
        self.listening = False
        self.status_var.set("Ready")
        self.listen_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
    
    def listen_for_command(self):
        with sr.Microphone() as source:
            self.recognizer.adjust_for_ambient_noise(source, duration=1)
            self.update_conversation(f"{self.assistant_name}: I'm listening...")
            
            try:
                audio = self.recognizer.listen(source, timeout=5)
                self.status_var.set("Processing...")
                
                try:
                    command = self.recognizer.recognize_google(audio).lower()
                    self.update_conversation(f"{self.user_name}: {command}")
                    self.process_command(command)
                except sr.UnknownValueError:
                    self.update_conversation(f"{self.assistant_name}: Sorry, I didn't catch that.")
                    self.speak("Sorry, I didn't catch that.")
                except sr.RequestError:
                    self.update_conversation(f"{self.assistant_name}: I'm having trouble connecting to the speech recognition service.")
                    self.speak("I'm having trouble connecting to the speech recognition service.")
            except Exception as e:
                self.update_conversation(f"{self.assistant_name}: Error: {str(e)}")
            
            self.stop_listening()
    
    def process_text_input(self, event=None):
        command = self.text_input.get().strip()
        if command:
            self.update_conversation(f"{self.user_name}: {command}")
            self.text_input.delete(0, tk.END)
            self.process_command(command.lower())
    
    def process_command(self, command):
        # Process the user's command
        command = command.lower().strip()
        
        # Greeting commands
        if any(word in command for word in ["hello", "hi", "hey", "greetings"]):
            self.greet()
        
        # Assistant information
        elif "your name" in command:
            self.update_conversation(f"{self.assistant_name}: My name is {self.assistant_name}. I'm your personal voice assistant.")
            self.speak(f"My name is {self.assistant_name}. I'm your personal voice assistant.")
        
        elif "my name" in command:
            self.update_conversation(f"{self.assistant_name}: Your name is {self.user_name}.")
            self.speak(f"Your name is {self.user_name}.")
        
        # Time and date
        elif any(word in command for word in ["time", "clock", "hour"]):
            self.tell_time()
        
        elif any(word in command for word in ["date", "day", "month", "year", "today"]):
            self.tell_date()
        
        # Wikipedia search
        elif ("search" in command and "wikipedia" in command) or ("wikipedia" in command):
            query = command
            for term in ["search wikipedia for", "search on wikipedia", "wikipedia", "search for", "tell me about", "what is", "who is"]:
                query = query.replace(term, "")
            query = query.strip()
            self.search_wikipedia(query)
        
        # Website opening
        elif "open" in command:
            if "google" in command or "chrome" in command:
                self.open_website("https://www.google.com")
                self.update_conversation(f"{self.assistant_name}: Opening Google...")
                self.speak("Opening Google.")
            elif "youtube" in command:
                self.open_website("https://www.youtube.com")
                self.update_conversation(f"{self.assistant_name}: Opening YouTube...")
                self.speak("Opening YouTube.")
            elif "facebook" in command:
                self.open_website("https://www.facebook.com")
                self.update_conversation(f"{self.assistant_name}: Opening Facebook...")
                self.speak("Opening Facebook.")
            elif "twitter" in command or "x" in command:
                self.open_website("https://www.twitter.com")
                self.update_conversation(f"{self.assistant_name}: Opening Twitter...")
                self.speak("Opening Twitter.")
            elif "instagram" in command:
                self.open_website("https://www.instagram.com")
                self.update_conversation(f"{self.assistant_name}: Opening Instagram...")
                self.speak("Opening Instagram.")
            elif "linkedin" in command:
                self.open_website("https://www.linkedin.com")
                self.update_conversation(f"{self.assistant_name}: Opening LinkedIn...")
                self.speak("Opening LinkedIn.")
            elif "github" in command:
                self.open_website("https://www.github.com")
                self.update_conversation(f"{self.assistant_name}: Opening GitHub...")
                self.speak("Opening GitHub.")
            else:
                self.update_conversation(f"{self.assistant_name}: I'm not sure which website to open. Please specify the website name.")
                self.speak("I'm not sure which website to open. Please specify the website name.")
        
        # Weather information
        elif "weather" in command:
            self.get_weather()
        
        # Jokes
        elif any(word in command for word in ["joke", "funny", "laugh", "humor"]):
            self.tell_joke()
        
        # Knowledge base queries
        elif self.check_knowledge_base(command):
            # This is handled in the check_knowledge_base method
            pass
        
        # Famous people Wikipedia search
        elif command.strip() in self.famous_people:
            self.search_wikipedia(command.strip())
        
        # Exit commands
        elif any(word in command for word in ["exit", "quit", "bye", "goodbye", "close", "stop"]):
            self.update_conversation(f"{self.assistant_name}: Goodbye! Have a great day!")
            self.speak("Goodbye! Have a great day!")
            self.root.after(2000, self.exit_app)
        
        # Help command
        elif "help" in command or "what can you do" in command:
            self.show_help()
        
        # Unknown command
        else:
            self.update_conversation(f"{self.assistant_name}: I'm not sure how to help with that yet. Try asking me about the Prime Minister of India, the time, or ask me to tell you a joke.")
            self.speak("I'm not sure how to help with that yet. Try asking me about the Prime Minister of India, the time, or ask me to tell you a joke.")
    
    def check_knowledge_base(self, command):
        """Check if the command matches any knowledge base entries"""
        command = command.lower()
        
        # Check for direct matches in knowledge base
        for key, value in self.knowledge_base.items():
            if key in command:
                self.update_conversation(f"{self.assistant_name}: {value}")
                self.speak(value)
                return True
        
        # Check for question patterns
        question_patterns = [
            r"who is (the |)([\w\s]+)",
            r"what is (the |)([\w\s]+)",
            r"tell me about (the |)([\w\s]+)",
            r"do you know (about |)(the |)([\w\s]+)"
        ]
        
        for pattern in question_patterns:
            match = re.search(pattern, command)
            if match:
                # Get the last group which contains the entity
                entity = match.group(match.lastindex).strip().lower()
                
                # Check if entity is in knowledge base
                for key, value in self.knowledge_base.items():
                    if entity in key or key in entity:
                        self.update_conversation(f"{self.assistant_name}: {value}")
                        self.speak(value)
                        return True
        
        return False
    
    def show_help(self):
        """Show help information about available commands"""
        help_text = "Here are some things you can ask me:\n\n"
        help_text += "• Ask for the time or date\n"
        help_text += "• Search Wikipedia for information\n"
        help_text += "• Open websites like Google, YouTube, Facebook, etc.\n"
        help_text += "• Ask about facts like 'Who is the Prime Minister of India?'\n"
        help_text += "• Ask me to tell you a joke\n"
        help_text += "• Change settings like my name, voice, or speech rate"
        
        self.update_conversation(f"{self.assistant_name}: {help_text}")
        self.speak("I can help you with many things. You can ask me for the time, search Wikipedia, open websites, ask about facts, tell jokes, or change my settings.")

    
    def greet(self):
        hour = datetime.datetime.now().hour
        greeting = ""
        
        if 5 <= hour < 12:
            greeting = "Good morning"
        elif 12 <= hour < 18:
            greeting = "Good afternoon"
        else:
            greeting = "Good evening"
        
        message = f"{greeting}, {self.user_name}! How can I help you today?"
        self.update_conversation(f"{self.assistant_name}: {message}")
        self.speak(message)
    
    def tell_time(self):
        current_time = datetime.datetime.now().strftime("%I:%M %p")
        message = f"The current time is {current_time}."
        self.update_conversation(f"{self.assistant_name}: {message}")
        self.speak(message)
    
    def tell_date(self):
        current_date = datetime.datetime.now().strftime("%A, %B %d, %Y")
        message = f"Today is {current_date}."
        self.update_conversation(f"{self.assistant_name}: {message}")
        self.speak(message)
    
    def search_wikipedia(self, query):
        if not query:
            self.update_conversation(f"{self.assistant_name}: What would you like me to search for on Wikipedia?")
            self.speak("What would you like me to search for on Wikipedia?")
            return
        
        self.update_conversation(f"{self.assistant_name}: Searching Wikipedia for {query}...")
        self.speak(f"Searching Wikipedia for {query}")
        
        try:
            result = wikipedia.summary(query, sentences=2)
            self.update_conversation(f"{self.assistant_name}: According to Wikipedia, {result}")
            self.speak(f"According to Wikipedia, {result}")
        except Exception as e:
            self.update_conversation(f"{self.assistant_name}: Sorry, I couldn't find any information about that on Wikipedia.")
            self.speak("Sorry, I couldn't find any information about that on Wikipedia.")
    
    def open_website(self, url):
        try:
            webbrowser.open(url)
        except Exception as e:
            self.update_conversation(f"{self.assistant_name}: Sorry, I couldn't open the website. {str(e)}")
            self.speak("Sorry, I couldn't open the website.")
    
    def get_weather(self):
        # This is a placeholder. In a real application, you would use a weather API
        self.update_conversation(f"{self.assistant_name}: I'm sorry, but I don't have access to weather information at the moment.")
        self.speak("I'm sorry, but I don't have access to weather information at the moment.")
    
    def tell_joke(self):
        jokes = [
            "Why don't scientists trust atoms? Because they make up everything!",
            "Did you hear about the mathematician who's afraid of negative numbers? He'll stop at nothing to avoid them!",
            "Why was the computer cold? It left its Windows open!",
            "What do you call a fake noodle? An impasta!",
            "Why did the scarecrow win an award? Because he was outstanding in his field!"
        ]
        joke = random.choice(jokes)
        self.update_conversation(f"{self.assistant_name}: {joke}")
        self.speak(joke)
    
    def open_settings(self):
        # Create settings window
        settings_window = tk.Toplevel(self.root)
        settings_window.title("Assistant Settings")
        settings_window.geometry("500x450")
        settings_window.configure(bg="#1E1E2E")
        settings_window.resizable(False, False)
        
        # Add window icon
        try:
            settings_window.iconbitmap("assistant_icon.ico")
        except:
            pass
        
        # Header
        header_frame = tk.Frame(settings_window, bg="#1E1E2E", height=60)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)
        
        header_label = tk.Label(header_frame, 
                              text="Assistant Settings", 
                              font=("Segoe UI", 18, "bold"),
                              fg="#CDD6F4", 
                              bg="#1E1E2E")
        header_label.pack(side=tk.LEFT, padx=20, pady=10)
        
        # Settings container with padding
        container = tk.Frame(settings_window, bg="#1E1E2E")
        container.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Create notebook for tabbed settings
        notebook = ttk.Notebook(container)
        notebook.pack(fill=tk.BOTH, expand=True, pady=10)
        
        # Style the notebook
        style = ttk.Style()
        style.configure("TNotebook", background="#1E1E2E", borderwidth=0)
        style.configure("TNotebook.Tab", background="#313244", foreground="#CDD6F4", padding=[10, 5], font=("Segoe UI", 10))
        style.map("TNotebook.Tab", background=[('selected', self.theme_color)], foreground=[('selected', '#1E1E2E')])
        
        # General settings tab
        general_tab = tk.Frame(notebook, bg="#1E1E2E")
        notebook.add(general_tab, text="General")
        
        # Voice settings tab
        voice_tab = tk.Frame(notebook, bg="#1E1E2E")
        notebook.add(voice_tab, text="Voice")
        
        # Appearance settings tab
        appearance_tab = tk.Frame(notebook, bg="#1E1E2E")
        notebook.add(appearance_tab, text="Appearance")
        
        # About tab
        about_tab = tk.Frame(notebook, bg="#1E1E2E")
        notebook.add(about_tab, text="About")
        
        # General tab content
        general_frame = tk.Frame(general_tab, bg="#1E1E2E", padx=15, pady=15)
        general_frame.pack(fill=tk.BOTH, expand=True)
        
        # Assistant name setting
        self.create_setting_field(general_frame, "Assistant Name:", self.assistant_name, "assistant_name_entry")
        
        # User name setting
        self.create_setting_field(general_frame, "User Name:", self.user_name, "user_name_entry")
        
        # Voice tab content
        voice_frame = tk.Frame(voice_tab, bg="#1E1E2E", padx=15, pady=15)
        voice_frame.pack(fill=tk.BOTH, expand=True)
        
        # Voice selection
        voice_label = tk.Label(voice_frame, 
                             text="Voice Type:", 
                             font=("Segoe UI", 12),
                             fg="#CDD6F4", 
                             bg="#1E1E2E")
        voice_label.pack(anchor="w", pady=(0, 10))
        
        voice_var = tk.StringVar()
        voice_var.set("Female" if self.engine.getProperty('voice') == self.voices[1].id else "Male")
        
        voice_options_frame = tk.Frame(voice_frame, bg="#1E1E2E")
        voice_options_frame.pack(fill=tk.X, pady=(0, 15))
        
        voice_male = tk.Radiobutton(voice_options_frame, 
                                  text="Male", 
                                  variable=voice_var, 
                                  value="Male",
                                  font=("Segoe UI", 11),
                                  fg="#CDD6F4", 
                                  bg="#1E1E2E",
                                  selectcolor="#313244",
                                  activebackground="#1E1E2E",
                                  activeforeground="#CDD6F4")
        voice_male.pack(side=tk.LEFT, padx=(0, 20))
        
        voice_female = tk.Radiobutton(voice_options_frame, 
                                    text="Female", 
                                    variable=voice_var, 
                                    value="Female",
                                    font=("Segoe UI", 11),
                                    fg="#CDD6F4", 
                                    bg="#1E1E2E",
                                    selectcolor="#313244",
                                    activebackground="#1E1E2E",
                                    activeforeground="#CDD6F4")
        voice_female.pack(side=tk.LEFT)
        
        # Speech rate
        rate_label = tk.Label(voice_frame, 
                            text="Speech Rate:", 
                            font=("Segoe UI", 12),
                            fg="#CDD6F4", 
                            bg="#1E1E2E")
        rate_label.pack(anchor="w", pady=(0, 10))
        
        rate_var = tk.IntVar()
        rate_var.set(self.engine.getProperty('rate'))
        
        rate_frame = tk.Frame(voice_frame, bg="#1E1E2E")
        rate_frame.pack(fill=tk.X)
        
        rate_scale = tk.Scale(rate_frame, 
                            from_=100, 
                            to=300, 
                            orient=tk.HORIZONTAL, 
                            variable=rate_var,
                            bg="#313244",
                            fg="#CDD6F4",
                            highlightthickness=0,
                            troughcolor="#1E1E2E",
                            activebackground=self.theme_color,
                            relief=tk.FLAT,
                            sliderrelief=tk.FLAT)
        rate_scale.pack(fill=tk.X)
        
        rate_value_frame = tk.Frame(voice_frame, bg="#1E1E2E")
        rate_value_frame.pack(fill=tk.X, pady=(5, 0))
        
        slow_label = tk.Label(rate_value_frame, text="Slow", font=("Segoe UI", 10), fg="#A6ADC8", bg="#1E1E2E")
        slow_label.pack(side=tk.LEFT)
        
        fast_label = tk.Label(rate_value_frame, text="Fast", font=("Segoe UI", 10), fg="#A6ADC8", bg="#1E1E2E")
        fast_label.pack(side=tk.RIGHT)
        
        # Test voice button
        test_voice_button = tk.Button(voice_frame, 
                                    text="Test Voice", 
                                    font=("Segoe UI", 11),
                                    bg=self.theme_color,
                                    fg="#1E1E2E",
                                    activebackground="#74C7EC",
                                    activeforeground="#1E1E2E",
                                    relief=tk.FLAT,
                                    padx=15,
                                    pady=8,
                                    command=lambda: self.test_voice(voice_var.get(), rate_var.get()))
        test_voice_button.pack(pady=15)
        
        # Appearance tab content
        appearance_frame = tk.Frame(appearance_tab, bg="#1E1E2E", padx=15, pady=15)
        appearance_frame.pack(fill=tk.BOTH, expand=True)
        
        # Theme selection
        theme_label = tk.Label(appearance_frame, 
                             text="Theme Color:", 
                             font=("Segoe UI", 12),
                             fg="#CDD6F4", 
                             bg="#1E1E2E")
        theme_label.pack(anchor="w", pady=(0, 10))
        
        theme_var = tk.StringVar()
        theme_var.set(self.theme_color)
        
        theme_options = [
            ("Blue", "#89DCEB"),
            ("Lavender", "#B4BEFE"),
            ("Green", "#A6E3A1"),
            ("Peach", "#FAB387"),
            ("Mauve", "#CBA6F7")
        ]
        
        theme_frame = tk.Frame(appearance_frame, bg="#1E1E2E")
        theme_frame.pack(fill=tk.X, pady=(0, 15))
        
        for i, (text, color) in enumerate(theme_options):
            theme_button = tk.Radiobutton(theme_frame, 
                                        text=text, 
                                        variable=theme_var, 
                                        value=color,
                                        font=("Segoe UI", 11),
                                        fg="#CDD6F4", 
                                        bg="#1E1E2E",
                                        selectcolor="#313244",
                                        activebackground="#1E1E2E",
                                        activeforeground="#CDD6F4")
            theme_button.grid(row=i//3, column=i%3, sticky="w", padx=5, pady=5)
        
        # About tab content
        about_frame = tk.Frame(about_tab, bg="#1E1E2E", padx=15, pady=15)
        about_frame.pack(fill=tk.BOTH, expand=True)
        
        about_title = tk.Label(about_frame, 
                              text="Smart AI Voice Assistant", 
                              font=("Segoe UI", 14, "bold"),
                              fg="#CDD6F4", 
                              bg="#1E1E2E")
        about_title.pack(pady=(0, 10))
        
        about_version = tk.Label(about_frame, 
                               text="Version 1.1.0", 
                               font=("Segoe UI", 10),
                               fg="#A6ADC8", 
                               bg="#1E1E2E")
        about_version.pack(pady=(0, 20))
        
        about_desc = tk.Label(about_frame, 
                            text="A modern, user-friendly voice assistant with\n" +
                                 "speech recognition, text-to-speech capabilities,\n" +
                                 "and a knowledge base of useful information.", 
                            font=("Segoe UI", 11),
                            fg="#CDD6F4", 
                            bg="#1E1E2E",
                            justify=tk.LEFT)
        about_desc.pack(anchor="w", pady=(0, 20))
        
        # Bottom buttons frame
        buttons_frame = tk.Frame(settings_window, bg="#1E1E2E", height=60)
        buttons_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Cancel button
        cancel_button = tk.Button(buttons_frame, 
                                text="Cancel", 
                                font=("Segoe UI", 11),
                                bg="#313244",
                                fg="#CDD6F4",
                                activebackground="#45475A",
                                activeforeground="#CDD6F4",
                                relief=tk.FLAT,
                                padx=15,
                                pady=8,
                                command=settings_window.destroy)
        cancel_button.pack(side=tk.RIGHT, padx=20)
        
        # Save button
        save_button = tk.Button(buttons_frame, 
                              text="Save Changes", 
                              font=("Segoe UI", 11, "bold"),
                              bg=self.theme_color,
                              fg="#1E1E2E",
                              activebackground="#74C7EC",
                              activeforeground="#1E1E2E",
                              relief=tk.FLAT,
                              padx=15,
                              pady=8,
                              command=lambda: self.save_settings(
                                  settings_window.nametowidget("assistant_name_entry").get(),
                                  settings_window.nametowidget("user_name_entry").get(),
                                  voice_var.get(),
                                  rate_var.get(),
                                  theme_var.get(),
                                  settings_window
                              ))
        save_button.pack(side=tk.RIGHT, padx=5)
    
    def create_setting_field(self, parent, label_text, default_value, widget_name):
        """Helper function to create a settings field with label and entry"""
        frame = tk.Frame(parent, bg="#1E1E2E")
        frame.pack(fill=tk.X, pady=10)
        
        label = tk.Label(frame, 
                        text=label_text, 
                        font=("Segoe UI", 12),
                        fg="#CDD6F4", 
                        bg="#1E1E2E")
        label.pack(anchor="w", pady=(0, 5))
        
        entry = tk.Entry(frame, 
                        name=widget_name,
                        font=("Segoe UI", 11),
                        bg="#313244",
                        fg="#CDD6F4",
                        insertbackground="#CDD6F4",
                        relief=tk.FLAT,
                        bd=8)  # Inner padding
        entry.insert(0, default_value)
        entry.pack(fill=tk.X)
        
        return entry
    
    def test_voice(self, voice_type, rate):
        """Test the selected voice settings"""
        # Save current settings
        current_voice = self.engine.getProperty('voice')
        current_rate = self.engine.getProperty('rate')
        
        # Apply test settings
        if voice_type == "Male":
            self.engine.setProperty('voice', self.voices[0].id)
        else:
            self.engine.setProperty('voice', self.voices[1].id)
        
        self.engine.setProperty('rate', rate)
        
        # Speak test message
        self.engine.say("This is a test of the selected voice settings.")
        self.engine.runAndWait()
        
        # Restore original settings
        self.engine.setProperty('voice', current_voice)
        self.engine.setProperty('rate', current_rate)
    
    def save_settings(self, assistant_name, user_name, voice, rate, theme_color, settings_window):
        # Update assistant name
        if assistant_name:
            self.assistant_name = assistant_name
        
        # Update user name
        if user_name:
            self.user_name = user_name
        
        # Update voice
        if voice == "Male":
            self.engine.setProperty('voice', self.voices[0].id)
        else:
            self.engine.setProperty('voice', self.voices[1].id)
        
        # Update speech rate
        self.engine.setProperty('rate', rate)
        
        # Update theme color
        self.theme_color = theme_color
        
        # Apply theme changes to UI elements
        self.apply_theme_changes()
        
        # Close settings window
        settings_window.destroy()
        
        # Confirm settings saved
        self.update_conversation(f"{self.assistant_name}: Settings saved successfully.")
        self.speak("Settings have been updated.")
    
    def apply_theme_changes(self):
        """Apply theme color changes to UI elements"""
        # Update listen button
        self.listen_button.configure(bg=self.theme_color, activebackground=self.theme_color)
        
        # Update send button
        self.send_button.configure(bg=self.theme_color, activebackground=self.theme_color)
        
        # Update status indicator when active
        if hasattr(self, 'status_indicator'):
            self.status_indicator.configure(bg=self.theme_color)
    
    def exit_app(self):
        self.root.quit()
        self.root.destroy()
        sys.exit()

# Main function
def main():
    root = tk.Tk()
    app = SmartVoiceAssistant(root)
    root.mainloop()

if __name__ == "__main__":
    main()